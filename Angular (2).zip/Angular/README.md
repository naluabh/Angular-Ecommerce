04a - SP1 - Atividade 1 - Implementação da Tela Inicial do site da loja de Jogos no Angular
Descrição:
Para realizar esta atividade é importante que você estude os conteúdos do Material digital, em especial aqueles que envolvam o desenvolvimento de componentes utilizando o framework Angular.

Para a entrega, você deverá entender a estrutura da linguagem TypeScript, quanto a:

    Instalação
    Sintaxe
    Diferenças de Typescript e Javascript
    Estrutura Orientada a objetos no Typescript: 

        o Classes e objetos
        o Métodos
        o Construtor

A partir deste estudo, você deverá implementar uma loja virtual (e-commerce) pelo framework Angular. E neste projeto você deverá instalar o Bootstrap e o Angular Material, e verificar todo o conteúdo e imagens que são necessárias para o desenvolvimento da página.

Com os componentes do Angular Material ou Bootstrap, utilizando HTML e CSS nesses componentes, você deverá criar menu, conteúdo, rodapé, formulário com os campos de usuário e senha e demais elementos da página inicial e tela de login do site.


